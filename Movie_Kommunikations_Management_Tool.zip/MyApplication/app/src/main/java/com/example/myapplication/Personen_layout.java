package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Personen_layout extends AppCompatActivity {

    TextView rolle;
    TextView date;
    TextView time;
    private Button task;
    private Button home;
    private Button crew;
    private Button hinzufuegen;
    String Name;
    personenlist personenlist;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personen_layout);

        //Rolle
        rolle=findViewById(R.id.id_rolle3);
        rolle.setText("Kamera");


        //Date
        date=findViewById(R.id.id_date3);
        Calendar calendar =Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        date.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        time =findViewById(R.id.id_time3);
        time.setText(currenttime);

        //Spinner Rolle
        Spinner spinner =findViewById(R.id.spinner_rolle);
        ArrayAdapter<CharSequence>adapter = ArrayAdapter.createFromResource(this,R.array.rollen, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        home = (Button)findViewById(R.id.id_home2);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityhome();
            }
        });

        task = (Button)findViewById(R.id.id_task2);
        task.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityTask();
            }
        });

        crew = (Button)findViewById(R.id.id_plan2);
        crew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityCrew();
            }
        });

        //Person hinzufügen


        hinzufuegen=findViewById(R.id.button_einfügen);


        EditText textname=(EditText)findViewById(R.id.editText_name);
        Name=(textname.getText().toString());
        final Intent i=new Intent(Personen_layout.this,personenlist.class);

        hinzufuegen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.putExtra("newname",Name);
            }
        });



    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public void openActivityCrew(){

        Intent intent= new Intent(this, personenlist.class);
        startActivity(intent);
    }


    public void openActivityTask(){

        Intent intent= new Intent(this,Aufgaben.class);
        startActivity(intent);
    }

    public void openActivityhome(){

        Intent intent= new Intent(this, Regisseur.class);
        startActivity(intent);
    }
}
