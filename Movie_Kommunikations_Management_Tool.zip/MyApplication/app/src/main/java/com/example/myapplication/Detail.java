package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Detail extends AppCompatActivity {

    Button Crew;
    int count=0;
    Button nachricht;
    Regisseur regiesseur;
    ListView cast;
    ArrayAdapter adapter;
    ListView vip;
    ArrayAdapter aAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        TextView rollee;
        TextView datee;
        TextView timee;
        TextView adresse;

        //Rolle
        rollee = findViewById(R.id.id_rolle5);
        rollee.setText("Kamera");

        //Date
        datee = findViewById(R.id.id_date5);
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        datee.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        timee = findViewById(R.id.id_time5);
        timee.setText(currenttime);


        Crew = (Button) findViewById(R.id.id_crew2);
        Crew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityCrew();
            }
        });

        String[] besetzung = new String[]{"Ulfed Maier          Rolle: Kamera", "Rohini Alavala         Rolle: Fahrer", "Trishika Dasari        Rolle: Technik", "Praveen Alavala        Rolle: Kamera", "George Abrams             Rolle: Regie"};
        cast=findViewById(R.id.besetzung);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, besetzung);
        cast.setAdapter(adapter);

        String[] important = new String[]{ "George Abrams             Rolle: Regie","Karl Baas                 Rolle:Arzt"};
        vip=findViewById(R.id.important);
        aAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, important);
        vip.setAdapter(aAdapter);

        adresse=findViewById(R.id.id_adresse);
        adresse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitymap();
            }
        });

    }

    public void openActivityCrew(){
        Intent intent= new Intent(this, personenlist.class);
        startActivity(intent);
    }

    public void openActivitymap(){
        Intent intent= new Intent(this, map.class);
        startActivity(intent);
    }






}
