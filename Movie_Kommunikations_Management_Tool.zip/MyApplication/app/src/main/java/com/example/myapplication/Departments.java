package com.example.myapplication;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Departments extends AppCompatActivity {

    private ListView aListView;
    private ArrayAdapter bAdapter;
    private String[] depart = { "Suresh Dasari", "Rohini Alavala", "Trishika Dasari", "Praveen Alavala", "Madav Sai", "Hamsika Yemineni"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regisseur);
       /* aListView = (ListView) findViewById(R.id.userlist1);
        bAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, depart);
        aListView.setAdapter(bAdapter);*/
    }
}


