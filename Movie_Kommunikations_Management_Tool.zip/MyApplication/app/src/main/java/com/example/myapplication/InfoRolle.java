package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class InfoRolle extends AppCompatActivity {
    TextView rolle;
    TextView date;
    TextView time;
    ImageButton kamera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_rolle);

        //Rolle
        rolle=findViewById(R.id.id_rolle8);
        rolle.setText("Kamera");

        //Date
        date=findViewById(R.id.id_date8);
        Calendar calendar =Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        date.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        time =findViewById(R.id.id_time8);
        time.setText(currenttime);


        kamera = (ImageButton) findViewById(R.id.image_kamera);
        kamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitywiki();
            }
        });
    }

    public void openActivitywiki(){

        Intent intent= new Intent(this, Wiki.class);
        startActivity(intent);
    }
}
