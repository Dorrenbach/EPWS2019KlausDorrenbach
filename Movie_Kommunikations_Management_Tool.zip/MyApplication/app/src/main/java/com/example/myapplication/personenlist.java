package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class personenlist extends AppCompatActivity {

    TextView rolle;
    TextView date;
    TextView time;
    private Button task;
    private Button home;
    ArrayAdapter aAdapter;
    ListView mListView;
    // private String[] users = { "Ulfed Maier          Rolle: Kamera", "Rohini Alavala         Rolle: Fahrer", "Trishika Dasari        Rolle: Technik", "Praveen Alavala        Rolle: Kamera", "George Abrams             Rolle: Regie", "Hamsika Yemineni       Rolle: Schauspieler"};
    Button btnperson_layout;
    String name;
    ArrayList<String> listItems=new ArrayList<String>();
    ArrayAdapter<String> adapter;
    ImageButton refresh;
    String st;








    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personenlist);


        mListView = (ListView) findViewById(R.id.userlist);
        listItems.add("Ulfred Maier");
        String[] users =new String[]{"Ulfed Maier          Rolle: Kamera", "Rohini Alavala         Rolle: Fahrer", "Trishika Dasari        Rolle: Technik", "Praveen Alavala        Rolle: Kamera", "George Abrams             Rolle: Regie", "Hamsika Yemineni       Rolle: Schauspieler"};
        aAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, users);
        mListView.setAdapter(aAdapter);

       // refresh=findViewById(R.id.imageButton_refresh);

       // st=getIntent().getExtras().getString("newname");

       /* refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatelist(st);
            }
        });*/


        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position==4){
                   Intent intent=new Intent(personenlist.this,Profil.class);
                   //Set name
                   String name="George Abrams";
                   intent.putExtra("Value",name);
                   //Set number
                    String number="1234567";
                    intent.putExtra("Valuenumber",number);
                   startActivity(intent);
                   //openActivitychat();


                }
            }
        });

        //Rolle
        rolle = findViewById(R.id.id_rolle2);
        rolle.setText("Kamera");


        //Date
        date = findViewById(R.id.id_date2);
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        date.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        time = findViewById(R.id.id_time2);
        time.setText(currenttime);


        btnperson_layout = (Button) findViewById(R.id.button_plus_person);
        btnperson_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityperson();
            }
        });

        home = (Button) findViewById(R.id.id_home3);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityhome();
            }
        });

        task = (Button) findViewById(R.id.id_task3);
        task.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityTask();
            }
        });



    }

    private void openActivityperson() {

        Intent intent= new Intent(this, Personen_layout.class);
        startActivity(intent);
    }

    private void openActivitychat() {

        Intent intent= new Intent(this, Profil.class);
        startActivity(intent);
    }

    private void openActivitymain() {

        Intent intent= new Intent(this, Regisseur.class);
        startActivity(intent);
    }

    public void openActivityTask(){

        Intent intent= new Intent(this,Aufgaben.class);
        startActivity(intent);
    }

    public void openActivityhome(){

        Intent intent= new Intent(this, Regisseur.class);
        startActivity(intent);
    }

    public void updatelist(String name){

        listItems.add(name);
        adapter.notifyDataSetChanged();
    }



}
