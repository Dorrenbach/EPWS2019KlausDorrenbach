package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button bress;
    private Button bkam;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        bress = (Button)findViewById(R.id.Regiesseur);
        bress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityRes();
            }
        });





    }




    public void openActivityRes(){

        Intent intent= new Intent(this, Regisseur.class);
        startActivity(intent);
    }

    public void openActivityKam(){

        Intent intent= new Intent(this, MainActivity.class);
        startActivity(intent);
    }


}
