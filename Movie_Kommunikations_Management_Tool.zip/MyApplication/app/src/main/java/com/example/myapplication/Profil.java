package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Profil extends AppCompatActivity {

    Button send;
    EditText chat,phone;
    TextView name;
    TextView number;
    TextView Chatlog;
    TextView antwort;
    String log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        if (ContextCompat.checkSelfPermission(Profil.this, Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(Profil.this, Manifest.permission.SEND_SMS)) {
                ActivityCompat.requestPermissions(Profil.this, new String[]{Manifest.permission.SEND_SMS}, 1);
            } else {
                ActivityCompat.requestPermissions(Profil.this, new String[]{Manifest.permission.SEND_SMS}, 1);
            }
        }else {
            //do nothing
        }
        //get name
        name=(TextView)findViewById(R.id.profilname);
        String st=getIntent().getExtras().getString("Value");
        name.setText(st);

        //get number
        number=(TextView)findViewById(R.id.phone);
        String stnumber=getIntent().getExtras().getString("Valuenumber");
        number.setText(stnumber);


        send =(Button)findViewById(R.id.button_senden);

        phone=(EditText)findViewById(R.id.phone);
        chat=(EditText)findViewById(R.id.chat);


        send.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                String number = phone.getText().toString();
                String sms =chat.getText().toString();

                try {
                    SmsManager smsManager=SmsManager.getDefault();
                    smsManager.sendTextMessage(number,null,sms,null,null);
                    Toast.makeText(Profil.this,"gesendet",Toast.LENGTH_SHORT).show();

                    log=chat.getText().toString();
                    Chatlog=(TextView)findViewById(R.id.chatlog);
                    Chatlog.setText(log);
                    Chatlog.setBackgroundColor(Color.parseColor("#194CAF50"));
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            // yourMethod();
                            antwort=(TextView)findViewById(R.id.antwort);
                            antwort.setText("Ich habe mich um eine Genehmigung gekümmert,danke :)");
                            antwort.setBackgroundColor(Color.parseColor("#4DFF0000"));
                        }
                    }, 5000);   //5 seconds


                }catch (Exception e){
                    Toast.makeText(Profil.this, "Error",Toast.LENGTH_SHORT).show();
                }
            }
        });

        };



    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,  int[] grantResults) {
        switch(requestCode){
            case 1:{
                if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    if (ContextCompat.checkSelfPermission(Profil.this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED){
                        Toast.makeText(this, "Permission granted!",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(this,"No permission granded!",Toast.LENGTH_SHORT).show();
                }
                return;
            }
    }
}
}
