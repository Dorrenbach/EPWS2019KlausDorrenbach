package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Aufgaben extends AppCompatActivity {
    TextView rolle;
    TextView date;
    TextView time;
    Button wiki;
    private Button Crew;
    private Button home;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aufgaben);

        //Rolle
        rolle=findViewById(R.id.id_rolle7);
        rolle.setText("Kamera");

        //Date
        date=findViewById(R.id.id_date7);
        Calendar calendar =Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        date.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        time =findViewById(R.id.id_time7);
        time.setText(currenttime);


        wiki=(Button)findViewById(R.id.button_wiki2);
        wiki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitywiki();
            }
        });


        Crew = (Button)findViewById(R.id.id_crew5);
        Crew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityCrew();
            }
        });

        home = (Button)findViewById(R.id.id_home7);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityhome();
            }
        });
    }


    public void openActivitywiki(){

        Intent intent= new Intent(this, InfoRolle.class);
        startActivity(intent);
    }

    public void openActivityCrew(){

        Intent intent= new Intent(this, personenlist.class);
        startActivity(intent);
    }

    public void openActivityhome(){

        Intent intent= new Intent(this, Regisseur.class);
        startActivity(intent);
    }
}
