package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Personen_layout extends AppCompatActivity {

    TextView rolle;
    TextView date;
    TextView time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personen_layout);

        //Rolle
        rolle=findViewById(R.id.id_rolle);
        rolle.setText("Kamera");


        //Date
        date=findViewById(R.id.id_date);
        Calendar calendar =Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        date.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        time =findViewById(R.id.id_time);
        time.setText(currenttime);



    }
}
