package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;


public class personenlist extends AppCompatActivity {

    private ArrayAdapter aAdapter;
    private String[] users = { "Ulfed Maier          Rolle: Kamera", "Rohini Alavala         Rolle: Fahrer", "Trishika Dasari        Rolle: Technik", "Praveen Alavala        Rolle: Kamera", "George Abrams             Rolle: Regie", "Hamsika Yemineni       Rolle: Schauspieler"};
    Button btnperson_layout;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personenlist);
        ListView mListView = (ListView) findViewById(R.id.userlist);
        aAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, users);
        mListView.setAdapter(aAdapter);


        btnperson_layout =(Button)findViewById(R.id.button_plus_person);
        btnperson_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityperson();
            }
        });

    }

    private void openActivityperson() {

        Intent intent= new Intent(this, Personen_layout.class);
        startActivity(intent);
    }

    private void openActivitymain() {

        Intent intent= new Intent(this, Regisseur.class);
        startActivity(intent);
    }

}
