package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Regisseur extends AppCompatActivity {
    MainActivity Main;
    TextView rolle;
    TextView date;
    TextView time;
    ListView listView;
    private ArrayList<String> personArray=new ArrayList<>();
    private Button Crew;
    Detail nach;
    Button regie;
    Button mess;
    Button wiki;
    Button task;
    CheckBox erledigt;
    TextView aufgabe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regisseur);

        //Rolle
        rolle=findViewById(R.id.id_rolle);
        rolle.setText("Kamera");


        //Date
        date=findViewById(R.id.id_date);
        Calendar calendar =Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        date.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        time =findViewById(R.id.id_time);
        time.setText(currenttime);



        //Departments
        //listView=findViewById(R.id.id_departments);
        //TestPerson.add(Test);
       // Departments Kamera=new Departments("Kamera",TestPerson,"ist für die Aufnahmen verantwortlich");
       // departments.add(Kamera);
        //ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,departments);
        //listView.setAdapter(arrayAdapter);

        //Personen

        Crew = (Button)findViewById(R.id.id_crew);
        Crew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityCrew();
            }
        });

        //Detail
        Button detail = (Button) findViewById(R.id.button_detail);
        detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitydetail();
            }
        });

        regie=(Button)findViewById(R.id.button_regie);
        mess=(Button)findViewById(R.id.button_message);
        mess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitynachricht();
            }
        });

        wiki=(Button)findViewById(R.id.button_wiki);
        wiki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitywiki();
            }
        });

        //Menue --> Aufgaben
        task = (Button)findViewById(R.id.id_task);
        task.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityTask();
            }
        });
        aufgabe=(TextView)findViewById(R.id.text_aufgabe);
        erledigt=(CheckBox)findViewById(R.id.checkBox);

        erledigt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (erledigt.isChecked()){

                    aufgabe.setText("Keine Aufgaben mehr");

                }
                else {
                    aufgabe.setText("18.12.2019 EXT Field/House DIST N17");
                }

            }
        });



        aufgabe.setText("18.12.2019 EXT Field/House DIST N17");





    }

    public void openActivityCrew(){

        Intent intent= new Intent(this, personenlist.class);
        startActivity(intent);
    }


    public void openActivityTask(){

        Intent intent= new Intent(this,Aufgaben.class);
        startActivity(intent);
    }

    public void openActivitydetail(){

        Intent intent= new Intent(this, Detail.class);
        startActivity(intent);
    }

    public void openActivitynachricht(){

        regie.setBackgroundColor(Color.parseColor("#4DFF0000"));
    }

    public void openActivitywiki(){

        Intent intent= new Intent(this, InfoRolle.class);
        startActivity(intent);
    }

    public void openErledigt(){

        aufgabe.setBackgroundColor(Color.WHITE);
    }

}
