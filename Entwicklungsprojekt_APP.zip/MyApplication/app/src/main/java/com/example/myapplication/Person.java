package com.example.myapplication;

public class Person {

    String name;
    String Rolle;
    int Alter;
    String Rechte;
    String Email;

    public Person(String name, String rolle, int alter, String rechte, String email) {
        this.name = name;
        Rolle = rolle;
        Alter = alter;
        Rechte = rechte;
        Email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRolle() {
        return Rolle;
    }

    public void setRolle(String rolle) {
        Rolle = rolle;
    }

    public int getAlter() {
        return Alter;
    }

    public void setAlter(int alter) {
        Alter = alter;
    }

    public String getRechte() {
        return Rechte;
    }

    public void setRechte(String rechte) {
        Rechte = rechte;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
