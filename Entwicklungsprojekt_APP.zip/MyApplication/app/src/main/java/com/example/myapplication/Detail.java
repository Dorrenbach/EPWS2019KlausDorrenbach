package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Detail extends AppCompatActivity {

    Button Crew;
    int count=0;
    Button nachricht;
    Regisseur regiesseur;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        TextView rollee;
        TextView datee;
        TextView timee;

        //Rolle
        rollee = findViewById(R.id.id_rolle5);
        rollee.setText("Kamera");

        //Date
        datee=findViewById(R.id.id_date5);
        Calendar calendar =Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        datee.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        timee =findViewById(R.id.id_time5);
        timee.setText(currenttime);


        Crew = (Button)findViewById(R.id.id_crew2);
        Crew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityCrew();
            }
        });

        nachricht=(Button)findViewById(R.id.button_nachicht);
        nachricht.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityback();
            }
        });


    }

    public void openActivityCrew(){
        Intent intent= new Intent(this, personenlist.class);
        startActivity(intent);
    }

    public void openActivityback(){
        Intent intent= new Intent(this, Regisseur.class);
        startActivity(intent);
        regiesseur.openActivitynachricht();
        Log.v("ROT","TOT");

    }




}
