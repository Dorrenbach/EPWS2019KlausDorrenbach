package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Wiki extends AppCompatActivity {

    ImageButton arusr;
    TextView rolle;
    TextView date;
    TextView time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wiki);

        arusr= (ImageButton) findViewById(R.id.image_ausruestung);
        arusr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityausr();
            }
        });


        //Rolle
        rolle=findViewById(R.id.id_rolle4);
        rolle.setText("Kamera");

        //Date
        date=findViewById(R.id.id_date4);
        Calendar calendar =Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime());
        date.setText(currentDate);

        //time
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        String currenttime = format.format(calendar.getTime());
        time =findViewById(R.id.id_time4);
        time.setText(currenttime);
    }

    public void openActivityausr(){

        Intent intent= new Intent(this,Doku.class);
        startActivity(intent);
    }
}
