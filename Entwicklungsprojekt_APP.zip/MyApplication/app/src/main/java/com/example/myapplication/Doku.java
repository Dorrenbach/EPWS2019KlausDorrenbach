package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Doku extends AppCompatActivity {

    Button drohne;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doku);

        drohne=(Button)findViewById(R.id.button_drohne);
        drohne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitydrohne();
            }
        });
    }

    public void openActivitydrohne(){

        Intent intent= new Intent(this, Drohne.class);
        startActivity(intent);
    }
}
